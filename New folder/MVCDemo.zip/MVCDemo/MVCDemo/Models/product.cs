﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCDemo.Models
{
    public class product
    {
        public int pid { get; set; }
        public string pname { get; set; }
        public Category categoryname { get; set; }
        public int prat { get; set; }
        public string pdes { get; set; }
    }
}