﻿using MVCDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDemo.Controllers
{
    public class ProductController : Controller
    {
        public class ProductCategory
        {
            public int pid { get; set; }
            public string pname { get; set; }
            public string categoryname { get; set; }
            public int prat { get; set; }
            public string pdes { get; set; }
        }
        private static List<product> products= new List<product>();

        private static List<Category> categories= new List<Category>();

        public ProductController() 
        {
            if (categories.Count < 1 )
            {
                categories.Add(new Category { cId=1, cname= "electronics" });
                categories.Add(new Category { cId=2, cname= "Furniture" });
                
            }

            if(products.Count < 1) { 
            products.Add(new product { pid = 1, pname = "TV", categoryname = categories.SingleOrDefault(i => i.cname.Equals("electronics")), prat = 5, pdes = "This is a tv" });
            products.Add(new product { pid = 2, pname = "Phone", categoryname = categories.SingleOrDefault(i => i.cname.Equals("electronics")), prat = 4, pdes = "This is a phone" });
            products.Add(new product { pid = 3, pname = "Table", categoryname = categories.SingleOrDefault(i => i.cname.Equals("Furniture")), prat = 3, pdes = "This is a table" });
            }
        }

        // GET: Product
        public ActionResult Index()
        {
            return View(products.ToList());
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            product pro = products.Find(x => x.pid == id);
            return View(pro);
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            List<SelectListItem> items = new List<SelectListItem>();
            foreach(var cat in categories)
            {
                items.Add(new SelectListItem { Text = cat.cname, Value = cat.cId.ToString() });
            }
            ViewBag.items = items;
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(ProductCategory newProduct)
        {
            try
            {
                product p = new product
                {
                    pid = products.Max(c=>c.pid) + 1,
                    pname = newProduct.pname,
                    categoryname = categories.SingleOrDefault(c => c.cId.ToString().Equals(newProduct.categoryname)),
                    prat = newProduct.prat,
                    pdes = newProduct.pdes,
                };
                products.Add(p);
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
            product pro = products.Find(x =>x.pid == id);
            List<SelectListItem> items = new List<SelectListItem>();
            foreach (var cat in categories)
            {
                items.Add(new SelectListItem { Text = cat.cname, Value = cat.cId.ToString() });
            }
            ViewBag.items = items;
            
            return View(pro);
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, ProductCategory model)
        {
            try
            {
                product pro = products.Find(x =>x.pid == id);
                pro.pname = model.pname;
                pro.categoryname = categories.SingleOrDefault(c => c.cId.ToString().Equals(model.categoryname));
                pro.prat = model.prat;
                pro.pdes = model.pdes;
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Delete/5
        public ActionResult Delete(int id)
        {
            product pro = products.Find(x =>x.pid == id);
            products.Remove(pro);
            return View();
        }

        // POST: Product/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
