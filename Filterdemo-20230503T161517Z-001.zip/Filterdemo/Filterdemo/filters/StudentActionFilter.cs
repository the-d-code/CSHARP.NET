﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace Filterdemo.filters
{
    public class StudentActionFilter : Attribute,IActionFilter
    {
        public StudentActionFilter(string Controllername,string Actionname)
        {
            Console.WriteLine(Controllername + " -> " + Actionname );
            _Controller = Controllername;
            _Action = Actionname;
        }

        public string _Controller { get; set; }
        public string _Action { get; set; }


        public void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine("Student Action Filter : Excuted",_Controller + "->" + _Action);
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            Console.WriteLine("Student Action Filter : Excuting", _Controller + "->" + _Action);
        }
    }
}
