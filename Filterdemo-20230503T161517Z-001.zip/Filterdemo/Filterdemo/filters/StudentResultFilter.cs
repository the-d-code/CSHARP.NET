﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace Filterdemo.filters
{
    public class StudentResultFilter : Attribute,IResultFilter
    {
        public void OnResultExecuted(ResultExecutedContext context)
        {
            Console.WriteLine("Student Result Filter : Executed ");
        }

        public void OnResultExecuting(ResultExecutingContext context)
        {
            Console.WriteLine("Student Result Filter : Executed ");
        }
    }
}
