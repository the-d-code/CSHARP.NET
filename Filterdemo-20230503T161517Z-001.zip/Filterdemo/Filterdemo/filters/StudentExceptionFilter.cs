﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace Filterdemo.filters
{
    public class StudentExceptionFilter : Attribute,IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            Console.WriteLine("Student Exception Filter : Executed ");
        }
    }
}
